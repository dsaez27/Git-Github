# Objetivos del repositorio

Este proyecto se encarga de manejar los planes de la liga de la justicia

Labore pariatur dolor ipsum exercitation sit. Consectetur elit fugiat ad nisi esse fugiat do officia eu excepteur culpa labore incididunt commodo. Fugiat in velit quis nostrud ut velit officia sit qui incididunt sint cillum magna eu. Exercitation dolore tempor qui aliqua est. Tempor duis excepteur ut aute. Minim esse aute qui cupidatat nostrud sunt. Aute tempor ea minim consequat incididunt ipsum occaecat pariatur.

