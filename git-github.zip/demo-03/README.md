## Pasos de instalación

Ejecutar
``
npm install
``

## Por omitir

Debemos omitir estos archivos y carpetas

node_modules
.log
.editorconfig