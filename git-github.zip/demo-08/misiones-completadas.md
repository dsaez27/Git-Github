# Misiones

* Crear la liga de la justicia
* Investigar los trabajos del Joker
* Tratar de investigar que trama el flash reverso